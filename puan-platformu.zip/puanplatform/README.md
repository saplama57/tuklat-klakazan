# ⚡ Puan Platformu

Gerçek backend + PostgreSQL veritabanına bağlı, oyunlaştırılmış puan kazanma
ve dijital ürün platformu. **Demo değildir** — her buton gerçek bir API
çağrısı yapar, her puan/limit/sipariş veritabanında kalıcı olarak saklanır.

## Teknoloji Yığını

- **Next.js 14** (App Router) + **TypeScript**
- **PostgreSQL** + **Prisma ORM**
- **NextAuth** (Credentials provider, bcrypt ile hash'lenmiş şifreler, JWT oturum)
- **Tailwind CSS**
- Sunucu tarafında **zod** ile input validasyonu

## Mimari İlkeler

- **Hiçbir kritik state client'ta tutulmaz.** Puan, tıklama limiti, turbo
  süresi, envanter — hepsi veritabanında saklanır ve her istekte sunucudan
  doğrulanır.
- **Her mutasyon transaction içinde çalışır.** Örn. `/api/click` tek bir
  Prisma transaction'ı içinde: limiti kontrol eder, turbo çarpanını hesaplar,
  puanı günceller, ClickEvent kaydı oluşturur ve günlük görev ilerlemesini
  günceller — hepsi ya birlikte başarılı olur ya da hiçbiri uygulanmaz.
- **Stok ve puan düşürme işlemleri koşullu (`updateMany` + `WHERE`) yapılır**,
  böylece eşzamanlı isteklerde negatif stok veya çift harcama oluşamaz.
- **Yetkilendirme her API route'unda sunucu tarafında kontrol edilir**
  (`requireUser`, `requireAdmin`) — middleware yalnızca ek bir UX katmanıdır,
  tek başına güvenlik sağlamaz.
- **Audit logging**: Her admin işlemi (`AdminLog` tablosu) kim/ne/kime/eski
  değer/yeni değer bilgisiyle kaydedilir.

## Kurulum

### 1. Bağımlılıkları yükleyin

```bash
npm install
```

### 2. PostgreSQL veritabanı hazırlayın

Yerelde Docker ile hızlıca bir Postgres ayağa kaldırabilirsiniz:

```bash
docker run --name puan-platformu-db \
  -e POSTGRES_PASSWORD=postgres \
  -e POSTGRES_DB=puan_platformu \
  -p 5432:5432 -d postgres:16
```

Veya Neon, Supabase, Railway, Render gibi yönetilen bir Postgres servisi
kullanabilirsiniz.

### 3. Ortam değişkenlerini ayarlayın

```bash
cp .env.example .env
```

`.env` dosyasını gerçek `DATABASE_URL` ve rastgele üretilmiş bir
`NEXTAUTH_SECRET` (`openssl rand -base64 32`) ile doldurun.

### 4. Veritabanı şemasını uygulayın

```bash
npx prisma migrate dev --name init
```

### 5. Başlangıç verisini yükleyin (SUPER_ADMIN, yükseltmeler, turbolar, görevler, örnek ürünler)

```bash
npm run db:seed
```

`.env` içindeki `SEED_SUPER_ADMIN_EMAIL` / `SEED_SUPER_ADMIN_PASSWORD` ile
giriş yapabilirsiniz. **Üretime almadan önce bu şifreyi mutlaka değiştirin.**

### 6. Geliştirme sunucusunu başlatın

```bash
npm run dev
```

`http://localhost:3000` adresinde uygulama çalışır.

## Üretime Alma (Deploy)

1. Kodu GitHub'a gönderin (`.env` dosyası `.gitignore` sayesinde asla
   gönderilmez).
2. Vercel / Railway / Render gibi bir platforma bağlayın.
3. Ortam değişkenlerini (`DATABASE_URL`, `NEXTAUTH_SECRET`, `NEXTAUTH_URL`)
   platform panelinden tanımlayın.
4. Build komutu otomatik olarak `prisma generate && next build` çalıştırır
   (`package.json` → `build` script'i).
5. İlk deploy sonrası `npx prisma migrate deploy` ve `npm run db:seed`
   komutlarını üretim veritabanına karşı bir kez çalıştırın.

## Proje Yapısı

```
src/
  app/
    api/            # Tüm backend endpoint'leri (route handlers)
    admin/           # Admin paneli sayfaları
    login/ register/ # Kimlik doğrulama sayfaları
    page.tsx         # Ana tıklama sayfası
  lib/
    prisma.ts        # Prisma client singleton
    auth.ts           # NextAuth yapılandırması
    security.ts       # requireUser/requireAdmin/rate-limit/audit-log yardımcıları
  middleware.ts       # Sayfa seviyesinde ek koruma (defense-in-depth)
prisma/
  schema.prisma       # Tüm veri modeli
  seed.ts              # Başlangıç verisi
```

## Rol Sistemi

| Rol | Yetkiler |
|---|---|
| `USER` | Tıklama, market, envanter, görevler, liderlik tablosu |
| `ADMIN` | `AdminGrant.permissions` içinde tanımlı yetkiler: `USER_MANAGEMENT`, `PRODUCT_MANAGEMENT`, `SUPPORT_MANAGEMENT`, `ANNOUNCEMENT_MANAGEMENT` |
| `SUPER_ADMIN` | Tüm yetkiler + admin atama/kaldırma |

## Güvenlik Notları

- Şifreler `bcryptjs` ile 12 salt round kullanılarak hash'lenir.
- Tüm API girdileri `zod` şemalarıyla sunucu tarafında doğrulanır.
- `/api/click`, `/api/market/purchase`, `/api/upgrades/purchase`,
  `/api/turbo/purchase` gibi kritik endpoint'ler ek olarak IP/kullanıcı
  bazlı rate limiting içerir.
- `.env` dosyası hiçbir zaman commit edilmemelidir; `.env.example` yalnızca
  değişken isimlerini içerir.

## Lisans

Bu proje şablon/başlangıç kodu olarak sağlanmıştır; ihtiyacınıza göre
özelleştirebilirsiniz.
