/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOT: bu dosyayı elle düzenlemeyin. `next dev` veya `next build` her çalıştığında yeniden oluşturulur.
