import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  // ---------------------------------------------------------------------
  // 1) İlk SUPER_ADMIN hesabı
  // ---------------------------------------------------------------------
  const email = (process.env.SEED_SUPER_ADMIN_EMAIL ?? "admin@example.com").toLowerCase();
  const username = process.env.SEED_SUPER_ADMIN_USERNAME ?? "superadmin";
  const password = process.env.SEED_SUPER_ADMIN_PASSWORD ?? "ChangeThisPassword123!";

  const passwordHash = await bcrypt.hash(password, 12);

  const superAdmin = await prisma.user.upsert({
    where: { email },
    update: { role: "SUPER_ADMIN" },
    create: {
      email,
      username,
      passwordHash,
      role: "SUPER_ADMIN",
      points: 0,
      pointsPerClick: 0.2,
      clicksRemaining: 200,
      clickLimitMax: 200,
    },
  });
  console.log(`✔ SUPER_ADMIN hazır: ${superAdmin.email}`);

  // ---------------------------------------------------------------------
  // 2) Roket Yükseltmesi zinciri (tıklama başına puan)
  // ---------------------------------------------------------------------
  const rocketLevels = [
    { level: 1, pointsPerClick: 0.2, price: 0 },
    { level: 2, pointsPerClick: 0.3, price: 50 },
    { level: 3, pointsPerClick: 0.5, price: 150 },
    { level: 4, pointsPerClick: 0.8, price: 400 },
    { level: 5, pointsPerClick: 1.0, price: 900 },
  ];

  for (const lvl of rocketLevels) {
    await prisma.upgrade.upsert({
      where: { key_level: { key: "rocket", level: lvl.level } },
      update: { pointsPerClick: lvl.pointsPerClick, price: lvl.price },
      create: {
        key: "rocket",
        level: lvl.level,
        name: "Roket Yükseltmesi",
        description: "Tıklama başına kazanılan puanı artırır.",
        icon: "🚀",
        pointsPerClick: lvl.pointsPerClick,
        price: lvl.price,
      },
    });
  }
  console.log("✔ Roket yükseltme zinciri (5 seviye) hazır");

  // ---------------------------------------------------------------------
  // 3) Turbo tipleri
  // ---------------------------------------------------------------------
  const turbos = [
    { key: "turbo_2x_5m", name: "2x Puan", icon: "⚡", multiplier: 2, durationSec: 5 * 60, price: 30 },
    { key: "turbo_3x_15m", name: "3x Puan", icon: "⚡", multiplier: 3, durationSec: 15 * 60, price: 100 },
    { key: "turbo_5x_1h", name: "5x Puan", icon: "🔥", multiplier: 5, durationSec: 60 * 60, price: 350 },
  ];
  for (const t of turbos) {
    await prisma.turboType.upsert({
      where: { key: t.key },
      update: { multiplier: t.multiplier, durationSec: t.durationSec, price: t.price },
      create: t,
    });
  }
  console.log("✔ Turbo tipleri hazır");

  // ---------------------------------------------------------------------
  // 4) Günlük görevler
  // ---------------------------------------------------------------------
  const tasks = [
    {
      key: "daily_login",
      title: "Günlük giriş yap",
      description: "Bugün platforma giriş yaptığınız için ödül kazanın.",
      type: "DAILY_LOGIN" as const,
      targetValue: 1,
      rewardPoints: 2,
    },
    {
      key: "click_50",
      title: "50 kez tıkla",
      description: "PUAN KAZAN butonuna bugün 50 kez tıklayın.",
      type: "CLICK_COUNT" as const,
      targetValue: 50,
      rewardPoints: 10,
    },
    {
      key: "earn_20_points",
      title: "20 puan kazan",
      description: "Tıklamalardan bugün toplam 20 puan kazanın.",
      type: "POINTS_EARNED" as const,
      targetValue: 20,
      rewardPoints: 8,
    },
    {
      key: "market_purchase_1",
      title: "Marketten ürün al",
      description: "Markette herhangi bir ürünü satın alın.",
      type: "MARKET_PURCHASE" as const,
      targetValue: 1,
      rewardPoints: 15,
    },
  ];
  for (const t of tasks) {
    await prisma.dailyTask.upsert({
      where: { key: t.key },
      update: t,
      create: t,
    });
  }
  console.log("✔ Günlük görevler hazır");

  // ---------------------------------------------------------------------
  // 5) Örnek market ürünleri
  // ---------------------------------------------------------------------
  const products = [
    {
      name: "Dijital Rozet Paketi",
      description: "Profilinizde görünen özel rozet koleksiyonu.",
      price: 50,
      stock: 999,
      category: "Kozmetik",
    },
    {
      name: "Premium Tema",
      description: "Uygulama arayüzü için özel renk teması.",
      price: 120,
      stock: 500,
      category: "Kozmetik",
    },
    {
      name: "1 Saatlik VIP Erişim",
      description: "1 saat boyunca VIP kullanıcı ayrıcalıkları.",
      price: 300,
      stock: 100,
      category: "Hizmet",
    },
  ];
  for (const p of products) {
    const existing = await prisma.product.findFirst({ where: { name: p.name } });
    if (!existing) {
      await prisma.product.create({ data: { ...p, status: "ACTIVE" } });
    }
  }
  console.log("✔ Örnek ürünler hazır");

  console.log("\n🎉 Seed tamamlandı.");
  console.log(`   SUPER_ADMIN giriş bilgileri: ${email} / (şifre .env'den okundu)`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
