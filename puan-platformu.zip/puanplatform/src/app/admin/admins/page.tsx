"use client";

import { useEffect, useState } from "react";

type AdminEntry = {
  id: string;
  username: string;
  email: string;
  role: string;
  adminGrant: { permissions: string[] } | null;
};

const ALL_PERMISSIONS = ["USER_MANAGEMENT", "PRODUCT_MANAGEMENT", "SUPPORT_MANAGEMENT", "ANNOUNCEMENT_MANAGEMENT"];

export default function AdminAdminsPage() {
  const [admins, setAdmins] = useState<AdminEntry[]>([]);
  const [userId, setUserId] = useState("");
  const [permissions, setPermissions] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  function load() {
    fetch("/api/admin/admins")
      .then((r) => r.json())
      .then((d) => setAdmins(d.admins ?? []));
  }
  useEffect(load, []);

  function togglePermission(p: string) {
    setPermissions((prev) => (prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]));
  }

  async function grant(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    const res = await fetch("/api/admin/admins", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, permissions }),
    });
    const data = await res.json();
    setSubmitting(false);
    if (!res.ok) {
      setError(data.error);
      return;
    }
    setUserId("");
    setPermissions([]);
    load();
  }

  async function revoke(id: string) {
    if (!window.confirm("Bu kullanıcının admin yetkisini kaldırmak istediğinize emin misiniz?")) return;
    await fetch(`/api/admin/admins/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">🛡️ Yönetici Yönetimi</h1>
      <p className="text-sm text-white/50">
        Yalnızca SUPER_ADMIN yeni admin atayabilir veya yetki kaldırabilir. Kullanıcı ID&apos;sini kullanıcı yönetimi
        sayfasından (arama sonuçları) bulabilirsiniz.
      </p>

      <form onSubmit={grant} className="card space-y-3 p-5">
        <input
          className="input"
          placeholder="Kullanıcı ID"
          required
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
        />
        <div className="flex flex-wrap gap-2">
          {ALL_PERMISSIONS.map((p) => (
            <button
              type="button"
              key={p}
              onClick={() => togglePermission(p)}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold ${
                permissions.includes(p) ? "bg-brand-600" : "bg-white/5 hover:bg-white/10"
              }`}
            >
              {p}
            </button>
          ))}
        </div>
        {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-400">{error}</p>}
        <button disabled={submitting || permissions.length === 0} className="btn-primary">
          {submitting ? "Atanıyor..." : "Admin Ata"}
        </button>
      </form>

      <div className="card divide-y divide-white/10">
        {admins.map((a) => (
          <div key={a.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
            <div>
              <p className="font-semibold">
                {a.username} <span className="text-xs text-white/40">({a.role})</span>
              </p>
              <p className="text-xs text-white/40">{a.email}</p>
              {a.adminGrant && (
                <p className="text-xs text-white/50">{a.adminGrant.permissions.join(", ")}</p>
              )}
            </div>
            {a.role === "ADMIN" && (
              <button onClick={() => revoke(a.id)} className="btn-secondary py-1 text-xs text-red-300">
                Yetkiyi Kaldır
              </button>
            )}
          </div>
        ))}
        {admins.length === 0 && <p className="p-6 text-center text-white/50">Henüz admin yok.</p>}
      </div>
    </div>
  );
}
