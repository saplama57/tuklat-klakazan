"use client";

import { useEffect, useState } from "react";

type Announcement = { id: string; title: string; description: string; publishedAt: string };

export default function AdminAnnouncementsPage() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  function load() {
    fetch("/api/announcements")
      .then((r) => r.json())
      .then((d) => setAnnouncements(d.announcements ?? []));
  }
  useEffect(load, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    const res = await fetch("/api/announcements", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, description }),
    });
    const data = await res.json();
    setSubmitting(false);
    if (!res.ok) {
      setError(data.error);
      return;
    }
    setTitle("");
    setDescription("");
    load();
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">📢 Duyurular</h1>

      <form onSubmit={submit} className="card space-y-3 p-5">
        <input className="input" placeholder="Başlık" required value={title} onChange={(e) => setTitle(e.target.value)} />
        <textarea
          className="input"
          placeholder="Açıklama"
          required
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-400">{error}</p>}
        <button disabled={submitting} className="btn-primary">
          {submitting ? "Yayınlanıyor..." : "Duyuru Yayınla"}
        </button>
      </form>

      <div className="card divide-y divide-white/10">
        {announcements.map((a) => (
          <div key={a.id} className="px-5 py-3">
            <p className="font-semibold">{a.title}</p>
            <p className="text-sm text-white/60">{a.description}</p>
            <p className="mt-1 text-xs text-white/30">{new Date(a.publishedAt).toLocaleString("tr-TR")}</p>
          </div>
        ))}
        {announcements.length === 0 && <p className="p-6 text-center text-white/50">Duyuru yok.</p>}
      </div>
    </div>
  );
}
