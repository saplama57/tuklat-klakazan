"use client";

import { useEffect, useState } from "react";

type LogEntry = {
  id: string;
  action: string;
  oldValue: string | null;
  newValue: string | null;
  createdAt: string;
  actor: { username: string; role: string };
  target: { username: string } | null;
};

export default function AdminLogsPage() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/admin/logs")
      .then((r) => r.json())
      .then((d) => setLogs(d.logs ?? []))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">🧾 Admin Logları</h1>
      {loading && <p className="text-white/50">Yükleniyor...</p>}

      <div className="card divide-y divide-white/10">
        {logs.map((l) => (
          <div key={l.id} className="px-5 py-3 text-sm">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="font-semibold">{l.action}</span>
              <span className="text-xs text-white/30">{new Date(l.createdAt).toLocaleString("tr-TR")}</span>
            </div>
            <p className="text-white/50">
              {l.actor.username} ({l.actor.role})
              {l.target && <> → {l.target.username}</>}
            </p>
            {(l.oldValue || l.newValue) && (
              <p className="text-xs text-white/40">
                {l.oldValue && <>eski: {l.oldValue} </>}
                {l.newValue && <>yeni: {l.newValue}</>}
              </p>
            )}
          </div>
        ))}
        {!loading && logs.length === 0 && <p className="p-6 text-center text-white/50">Log kaydı yok.</p>}
      </div>
    </div>
  );
}
