"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

type Stats = {
  totalUsers: number;
  activeUsers: number;
  bannedUsers: number;
  totalPoints: string;
  todaysPointsEarned: string;
  totalClicks: number;
  todaysClicks: number;
  totalOrders: number;
  todaysOrders: number;
  totalProducts: number;
  lowStockProducts: { id: string; name: string; stock: number }[];
  openTickets: number;
};

const tiles = [
  { key: "totalUsers", label: "Toplam Kullanıcı" },
  { key: "activeUsers", label: "Aktif Kullanıcı (24s)" },
  { key: "bannedUsers", label: "Banlı Kullanıcı" },
  { key: "totalPoints", label: "Toplam Puan" },
  { key: "todaysPointsEarned", label: "Bugün Kazanılan Puan" },
  { key: "totalClicks", label: "Toplam Tıklama" },
  { key: "todaysClicks", label: "Günlük Tıklama" },
  { key: "totalOrders", label: "Toplam Sipariş" },
  { key: "todaysOrders", label: "Günlük Sipariş" },
  { key: "totalProducts", label: "Toplam Ürün" },
  { key: "openTickets", label: "Açık Destek Talebi" },
] as const;

const adminLinks = [
  { href: "/admin/users", label: "👥 Kullanıcı Yönetimi" },
  { href: "/admin/products", label: "📦 Ürün Yönetimi" },
  { href: "/admin/announcements", label: "📢 Duyurular" },
  { href: "/admin/admins", label: "🛡️ Yönetici Yönetimi" },
  { href: "/admin/logs", label: "🧾 Admin Logları" },
];

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    fetch("/api/admin/dashboard")
      .then((r) => r.json())
      .then(setStats);
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">🛠️ Admin Paneli</h1>

      <div className="flex flex-wrap gap-2">
        {adminLinks.map((l) => (
          <Link key={l.href} href={l.href} className="btn-secondary text-sm">
            {l.label}
          </Link>
        ))}
      </div>

      {!stats && <p className="text-white/50">Yükleniyor...</p>}

      {stats && (
        <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
          {tiles.map((t) => (
            <div key={t.key} className="card p-4">
              <p className="text-xs uppercase tracking-wide text-white/40">{t.label}</p>
              <p className="mt-1 text-2xl font-bold tabular-nums">{String(stats[t.key])}</p>
            </div>
          ))}
        </div>
      )}

      {stats && stats.lowStockProducts.length > 0 && (
        <div className="card p-5">
          <h2 className="mb-3 font-bold text-amber-400">⚠️ Düşük Stoklu Ürünler</h2>
          <ul className="space-y-1 text-sm">
            {stats.lowStockProducts.map((p) => (
              <li key={p.id} className="flex justify-between">
                <span>{p.name}</span>
                <span className="text-white/50">{p.stock} adet</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
