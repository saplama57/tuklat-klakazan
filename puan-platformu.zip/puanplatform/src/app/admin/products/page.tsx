"use client";

import { useEffect, useState } from "react";

type Product = {
  id: string;
  name: string;
  description: string | null;
  imageUrl: string | null;
  price: string;
  stock: number;
  category: string;
  status: string;
};

const emptyForm = { name: "", description: "", imageUrl: "", price: "", stock: "", category: "" };

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  function load() {
    fetch("/api/market/products")
      .then((r) => r.json())
      .then((d) => setProducts(d.products ?? []));
  }

  useEffect(load, []);

  async function createProduct(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    const res = await fetch("/api/market/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: form.name,
        description: form.description || undefined,
        imageUrl: form.imageUrl || undefined,
        price: Number(form.price),
        stock: Number(form.stock),
        category: form.category,
      }),
    });
    const data = await res.json();
    setSubmitting(false);
    if (!res.ok) {
      setError(data.error);
      return;
    }
    setForm(emptyForm);
    load();
  }

  async function hideProduct(id: string) {
    if (!window.confirm("Bu ürünü gizlemek istediğinize emin misiniz?")) return;
    await fetch(`/api/market/products/${id}`, { method: "DELETE" });
    load();
  }

  async function restockProduct(p: Product) {
    const input = window.prompt("Yeni stok miktarı:", String(p.stock));
    if (!input) return;
    const stock = Number(input);
    if (Number.isNaN(stock)) return;
    await fetch(`/api/market/products/${p.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ stock, status: stock > 0 ? "ACTIVE" : "OUT_OF_STOCK" }),
    });
    load();
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">📦 Ürün Yönetimi</h1>

      <form onSubmit={createProduct} className="card grid gap-3 p-5 sm:grid-cols-2">
        <input
          className="input"
          placeholder="Ürün adı"
          required
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
        />
        <input
          className="input"
          placeholder="Kategori"
          required
          value={form.category}
          onChange={(e) => setForm({ ...form, category: e.target.value })}
        />
        <input
          className="input"
          placeholder="Fiyat (puan)"
          type="number"
          step="0.01"
          required
          value={form.price}
          onChange={(e) => setForm({ ...form, price: e.target.value })}
        />
        <input
          className="input"
          placeholder="Stok"
          type="number"
          required
          value={form.stock}
          onChange={(e) => setForm({ ...form, stock: e.target.value })}
        />
        <input
          className="input sm:col-span-2"
          placeholder="Görsel URL (opsiyonel)"
          value={form.imageUrl}
          onChange={(e) => setForm({ ...form, imageUrl: e.target.value })}
        />
        <textarea
          className="input sm:col-span-2"
          placeholder="Açıklama (opsiyonel)"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
        />
        {error && <p className="sm:col-span-2 rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-400">{error}</p>}
        <button disabled={submitting} className="btn-primary sm:col-span-2">
          {submitting ? "Ekleniyor..." : "Ürün Ekle"}
        </button>
      </form>

      <div className="card divide-y divide-white/10">
        {products.map((p) => (
          <div key={p.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
            <div>
              <p className="font-semibold">{p.name}</p>
              <p className="text-xs text-white/40">
                {p.category} · {Number(p.price).toFixed(2)} P · Stok: {p.stock} · {p.status}
              </p>
            </div>
            <div className="flex gap-2">
              <button onClick={() => restockProduct(p)} className="btn-secondary py-1 text-xs">
                Stok Güncelle
              </button>
              <button onClick={() => hideProduct(p.id)} className="btn-secondary py-1 text-xs text-red-300">
                Gizle
              </button>
            </div>
          </div>
        ))}
        {products.length === 0 && <p className="p-6 text-center text-white/50">Ürün yok.</p>}
      </div>
    </div>
  );
}
