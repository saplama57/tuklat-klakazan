"use client";

import { useEffect, useState } from "react";

type AdminUser = {
  id: string;
  email: string;
  username: string;
  role: string;
  points: string;
  totalClicks: number;
  clicksRemaining: number;
  clickLimitMax: number;
  isBanned: boolean;
  banReason: string | null;
  createdAt: string;
};

export default function AdminUsersPage() {
  const [query, setQuery] = useState("");
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function search() {
    setLoading(true);
    setError(null);
    const res = await fetch(`/api/admin/users?q=${encodeURIComponent(query)}`);
    const data = await res.json();
    if (!res.ok) {
      setError(data.error);
      setLoading(false);
      return;
    }
    setUsers(data.users);
    setLoading(false);
  }

  useEffect(() => {
    search();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function performAction(userId: string, body: Record<string, unknown>) {
    setBusyId(userId);
    setError(null);
    const res = await fetch(`/api/admin/users/${userId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    setBusyId(null);
    if (!res.ok) {
      setError(data.error);
      return;
    }
    search();
  }

  async function toggleBan(u: AdminUser) {
    if (u.isBanned) {
      performAction(u.id, { action: "UNBAN" });
    } else {
      const reason = window.prompt("Ban sebebi:");
      if (!reason) return;
      performAction(u.id, { action: "BAN", reason });
    }
  }

  function adjustPoints(u: AdminUser) {
    const input = window.prompt("Eklenecek/çıkarılacak puan (negatif değer de girilebilir):");
    if (!input) return;
    const amount = Number(input);
    if (Number.isNaN(amount)) return;
    const reason = window.prompt("Sebep:") ?? "Admin düzenlemesi";
    performAction(u.id, { action: "ADJUST_POINTS", amount, reason });
  }

  function adjustLimit(u: AdminUser) {
    const input = window.prompt("Yeni maksimum tıklama limiti:", String(u.clickLimitMax));
    if (!input) return;
    const clickLimitMax = Number(input);
    if (Number.isNaN(clickLimitMax)) return;
    performAction(u.id, { action: "ADJUST_LIMIT", clickLimitMax });
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">👥 Kullanıcı Yönetimi</h1>

      <div className="flex gap-2">
        <input
          className="input"
          placeholder="Kullanıcı adı veya e-posta ara..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && search()}
        />
        <button onClick={search} className="btn-primary">
          Ara
        </button>
      </div>

      {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-400">{error}</p>}
      {loading && <p className="text-white/50">Yükleniyor...</p>}

      <div className="card divide-y divide-white/10">
        {users.map((u) => (
          <div key={u.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
            <div>
              <p className="font-semibold">
                {u.username} <span className="text-xs text-white/40">({u.role})</span>{" "}
                {u.isBanned && <span className="rounded bg-red-500/20 px-2 py-0.5 text-xs text-red-300">BANLI</span>}
              </p>
              <p className="text-xs text-white/40">{u.email}</p>
              <p className="text-xs text-white/50">
                {Number(u.points).toFixed(2)} P · {u.totalClicks} tıklama · limit {u.clicksRemaining}/{u.clickLimitMax}
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button disabled={busyId === u.id} onClick={() => adjustPoints(u)} className="btn-secondary py-1 text-xs">
                Puan Düzenle
              </button>
              <button disabled={busyId === u.id} onClick={() => adjustLimit(u)} className="btn-secondary py-1 text-xs">
                Limit Düzenle
              </button>
              <button
                disabled={busyId === u.id}
                onClick={() => toggleBan(u)}
                className={`py-1 text-xs ${u.isBanned ? "btn-secondary" : "btn-primary"}`}
              >
                {u.isBanned ? "Ban Kaldır" : "Banla"}
              </button>
            </div>
          </div>
        ))}
        {!loading && users.length === 0 && <p className="p-6 text-center text-white/50">Kullanıcı bulunamadı.</p>}
      </div>
    </div>
  );
}
