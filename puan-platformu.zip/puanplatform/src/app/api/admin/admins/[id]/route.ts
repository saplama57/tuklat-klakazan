import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiError, handleApiError, requireAdmin, requireSuperAdminRole, writeAdminLog } from "@/lib/security";

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const actor = await requireAdmin();
    requireSuperAdminRole(actor.role);

    const target = await prisma.user.findUnique({ where: { id: params.id } });
    if (!target) throw new ApiError(404, "Kullanıcı bulunamadı.");
    if (target.role !== "ADMIN") throw new ApiError(400, "Bu kullanıcı bir ADMIN değil.");

    await prisma.$transaction(async (tx) => {
      await tx.user.update({ where: { id: target.id }, data: { role: "USER" } });
      await tx.adminGrant.deleteMany({ where: { userId: target.id } });
    });

    await writeAdminLog({ actorId: actor.id, targetId: target.id, action: "ADMIN_REVOKE" });

    return NextResponse.json({ success: true });
  } catch (err) {
    return handleApiError(err);
  }
}
