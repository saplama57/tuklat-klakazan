import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, handleApiError, requireAdmin, requireSuperAdminRole, writeAdminLog } from "@/lib/security";

const VALID_PERMISSIONS = [
  "USER_MANAGEMENT",
  "PRODUCT_MANAGEMENT",
  "SUPPORT_MANAGEMENT",
  "ANNOUNCEMENT_MANAGEMENT",
] as const;

export async function GET() {
  try {
    await requireAdmin(); // SUPER_ADMIN veya ADMIN görüntüleyebilir
    const admins = await prisma.user.findMany({
      where: { role: { in: ["ADMIN", "SUPER_ADMIN"] } },
      select: {
        id: true,
        username: true,
        email: true,
        role: true,
        createdAt: true,
        adminGrant: { select: { permissions: true, grantedById: true, createdAt: true } },
      },
      orderBy: { createdAt: "asc" },
    });
    return NextResponse.json({ admins });
  } catch (err) {
    return handleApiError(err);
  }
}

const grantSchema = z.object({
  userId: z.string().min(1),
  permissions: z.array(z.enum(VALID_PERMISSIONS)).min(1),
});

export async function POST(req: NextRequest) {
  try {
    const actor = await requireAdmin();
    requireSuperAdminRole(actor.role); // sadece SUPER_ADMIN yeni admin atayabilir

    const body = await req.json();
    const parsed = grantSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Geçersiz veri." }, { status: 400 });
    }

    const target = await prisma.user.findUnique({ where: { id: parsed.data.userId } });
    if (!target) throw new ApiError(404, "Kullanıcı bulunamadı.");
    if (target.role === "SUPER_ADMIN") throw new ApiError(400, "Bu kullanıcı zaten SUPER_ADMIN.");

    const result = await prisma.$transaction(async (tx) => {
      const updatedUser = await tx.user.update({ where: { id: target.id }, data: { role: "ADMIN" } });
      const grant = await tx.adminGrant.upsert({
        where: { userId: target.id },
        create: { userId: target.id, grantedById: actor.id, permissions: parsed.data.permissions },
        update: { permissions: parsed.data.permissions, grantedById: actor.id },
      });
      return { updatedUser, grant };
    });

    await writeAdminLog({
      actorId: actor.id,
      targetId: target.id,
      action: "ADMIN_GRANT",
      newValue: JSON.stringify(parsed.data.permissions),
    });

    return NextResponse.json({ user: result.updatedUser, grant: result.grant });
  } catch (err) {
    return handleApiError(err);
  }
}
