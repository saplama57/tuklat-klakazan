import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { handleApiError, requireAdmin, utcDayStart } from "@/lib/security";

export async function GET() {
  try {
    await requireAdmin();
    const today = utcDayStart();

    const [
      totalUsers,
      bannedUsers,
      activeUsers, // son 24 saatte tıklama yapan
      pointsAgg,
      todaysClickEvents,
      totalClicks,
      totalOrders,
      todaysOrders,
      totalProducts,
      lowStockProducts,
      openTickets,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { isBanned: true } }),
      prisma.user.count({ where: { lastActiveDate: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } } }),
      prisma.user.aggregate({ _sum: { points: true } }),
      prisma.clickEvent.aggregate({
        _sum: { pointsAwarded: true },
        _count: true,
        where: { createdAt: { gte: today } },
      }),
      prisma.clickEvent.count(),
      prisma.order.count(),
      prisma.order.count({ where: { createdAt: { gte: today } } }),
      prisma.product.count({ where: { status: { not: "HIDDEN" } } }),
      prisma.product.findMany({
        where: { stock: { lte: 5 }, status: { not: "HIDDEN" } },
        select: { id: true, name: true, stock: true },
        take: 10,
      }),
      prisma.supportTicket.count({ where: { status: "OPEN" } }),
    ]);

    return NextResponse.json({
      totalUsers,
      activeUsers,
      bannedUsers,
      totalPoints: pointsAgg._sum.points ?? 0,
      todaysPointsEarned: todaysClickEvents._sum.pointsAwarded ?? 0,
      totalClicks,
      todaysClicks: todaysClickEvents._count,
      totalOrders,
      todaysOrders,
      totalProducts,
      lowStockProducts,
      openTickets,
    });
  } catch (err) {
    return handleApiError(err);
  }
}
