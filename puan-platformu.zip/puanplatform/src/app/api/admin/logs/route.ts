import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { handleApiError, requireAdmin } from "@/lib/security";

export async function GET(req: NextRequest) {
  try {
    const actor = await requireAdmin();
    // Sadece SUPER_ADMIN tüm logları görebilir; sıradan ADMIN yalnızca
    // kendi yaptığı işlemleri görebilir.
    const isSuperAdmin = actor.role === "SUPER_ADMIN";

    const page = Number(req.nextUrl.searchParams.get("page") ?? "1");
    const pageSize = 50;

    const logs = await prisma.adminLog.findMany({
      where: isSuperAdmin ? undefined : { actorId: actor.id },
      include: {
        actor: { select: { username: true, role: true } },
        target: { select: { username: true } },
      },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
    });

    return NextResponse.json({ logs, page });
  } catch (err) {
    return handleApiError(err);
  }
}
