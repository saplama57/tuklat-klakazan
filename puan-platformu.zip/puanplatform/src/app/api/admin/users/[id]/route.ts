import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, handleApiError, notifyUser, requireAdmin, writeAdminLog } from "@/lib/security";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await requireAdmin("USER_MANAGEMENT");
    const user = await prisma.user.findUnique({
      where: { id: params.id },
      include: {
        orders: { include: { product: { select: { name: true } } }, orderBy: { createdAt: "desc" }, take: 20 },
        bans: { orderBy: { createdAt: "desc" }, take: 10 },
      },
    });
    if (!user) throw new ApiError(404, "Kullanıcı bulunamadı.");
    const { passwordHash, ...safeUser } = user;
    return NextResponse.json({ user: safeUser });
  } catch (err) {
    return handleApiError(err);
  }
}

const actionSchema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("BAN"), reason: z.string().min(3).max(500) }),
  z.object({ action: z.literal("UNBAN") }),
  z.object({ action: z.literal("ADJUST_POINTS"), amount: z.number(), reason: z.string().min(3).max(500) }),
  z.object({ action: z.literal("ADJUST_LIMIT"), clickLimitMax: z.number().int().min(1).max(100000) }),
]);

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const admin = await requireAdmin("USER_MANAGEMENT");
    const body = await req.json();
    const parsed = actionSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message ?? "Geçersiz veri." },
        { status: 400 },
      );
    }

    const target = await prisma.user.findUnique({ where: { id: params.id } });
    if (!target) throw new ApiError(404, "Kullanıcı bulunamadı.");

    // Adminler diğer adminleri/super adminleri yönetemez; sadece SUPER_ADMIN yönetebilir.
    if (target.role !== "USER" && admin.role !== "SUPER_ADMIN") {
      throw new ApiError(403, "Yönetici hesapları üzerinde işlem yapmak için SUPER_ADMIN gereklidir.");
    }

    const data = parsed.data;

    if (data.action === "BAN") {
      const updated = await prisma.$transaction(async (tx) => {
        const u = await tx.user.update({
          where: { id: target.id },
          data: { isBanned: true, bannedAt: new Date(), banReason: data.reason },
        });
        await tx.banRecord.create({
          data: { userId: target.id, issuedById: admin.id, reason: data.reason },
        });
        return u;
      });
      await writeAdminLog({
        actorId: admin.id,
        targetId: target.id,
        action: "USER_BAN",
        oldValue: "false",
        newValue: "true",
        metadata: { reason: data.reason },
      });
      return NextResponse.json({ user: updated });
    }

    if (data.action === "UNBAN") {
      const updated = await prisma.$transaction(async (tx) => {
        const u = await tx.user.update({
          where: { id: target.id },
          data: { isBanned: false, bannedAt: null, banReason: null },
        });
        await tx.banRecord.updateMany({
          where: { userId: target.id, liftedAt: null },
          data: { liftedAt: new Date() },
        });
        return u;
      });
      await writeAdminLog({ actorId: admin.id, targetId: target.id, action: "USER_UNBAN", oldValue: "true", newValue: "false" });
      return NextResponse.json({ user: updated });
    }

    if (data.action === "ADJUST_POINTS") {
      const updated = await prisma.user.update({
        where: { id: target.id },
        data: { points: { increment: data.amount } },
      });
      await writeAdminLog({
        actorId: admin.id,
        targetId: target.id,
        action: "POINTS_ADJUST",
        oldValue: target.points.toString(),
        newValue: updated.points.toString(),
        metadata: { delta: data.amount, reason: data.reason },
      });
      await notifyUser({
        userId: target.id,
        type: "ADMIN_ACTION",
        title: "Puanınız güncellendi",
        message: `Bir yönetici hesabınıza ${data.amount > 0 ? "+" : ""}${data.amount} puan uyguladı.`,
      });
      return NextResponse.json({ user: updated });
    }

    if (data.action === "ADJUST_LIMIT") {
      const updated = await prisma.user.update({
        where: { id: target.id },
        data: { clickLimitMax: data.clickLimitMax },
      });
      await writeAdminLog({
        actorId: admin.id,
        targetId: target.id,
        action: "LIMIT_ADJUST",
        oldValue: String(target.clickLimitMax),
        newValue: String(data.clickLimitMax),
      });
      return NextResponse.json({ user: updated });
    }

    throw new ApiError(400, "Bilinmeyen işlem.");
  } catch (err) {
    return handleApiError(err);
  }
}
