import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { handleApiError, requireAdmin } from "@/lib/security";

export async function GET(req: NextRequest) {
  try {
    await requireAdmin("USER_MANAGEMENT");
    const q = req.nextUrl.searchParams.get("q")?.trim();

    const users = await prisma.user.findMany({
      where: q
        ? {
            OR: [
              { username: { contains: q, mode: "insensitive" } },
              { email: { contains: q, mode: "insensitive" } },
            ],
          }
        : undefined,
      orderBy: { createdAt: "desc" },
      take: 50,
      select: {
        id: true,
        email: true,
        username: true,
        role: true,
        points: true,
        totalClicks: true,
        clicksRemaining: true,
        clickLimitMax: true,
        isBanned: true,
        banReason: true,
        createdAt: true,
      },
    });

    return NextResponse.json({ users });
  } catch (err) {
    return handleApiError(err);
  }
}
