import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { handleApiError, requireAdmin, requireUser, writeAdminLog } from "@/lib/security";

export async function GET() {
  try {
    await requireUser();
    const announcements = await prisma.announcement.findMany({
      where: { isActive: true, publishedAt: { lte: new Date() } },
      orderBy: { publishedAt: "desc" },
      take: 20,
    });
    return NextResponse.json({ announcements });
  } catch (err) {
    return handleApiError(err);
  }
}

const schema = z.object({
  title: z.string().min(2).max(150),
  description: z.string().min(2).max(4000),
  imageUrl: z.string().url().optional().or(z.literal("")),
  publishedAt: z.string().datetime().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const admin = await requireAdmin("ANNOUNCEMENT_MANAGEMENT");
    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Geçersiz veri." }, { status: 400 });
    }

    const announcement = await prisma.announcement.create({
      data: {
        title: parsed.data.title,
        description: parsed.data.description,
        imageUrl: parsed.data.imageUrl || null,
        publishedAt: parsed.data.publishedAt ? new Date(parsed.data.publishedAt) : new Date(),
        createdById: admin.id,
      },
    });

    const users = await prisma.user.findMany({ where: { isBanned: false }, select: { id: true }, take: 1000 });
    await prisma.notification.createMany({
      data: users.map((u) => ({
        userId: u.id,
        type: "ANNOUNCEMENT" as const,
        title: "Yeni duyuru",
        message: announcement.title,
      })),
    });

    await writeAdminLog({ actorId: admin.id, action: "ANNOUNCEMENT_CREATE", newValue: JSON.stringify(announcement) });

    return NextResponse.json({ announcement }, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}
