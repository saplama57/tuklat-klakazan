import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { checkRateLimit, handleApiError } from "@/lib/security";

const registerSchema = z.object({
  email: z.string().email("Geçerli bir e-posta adresi girin."),
  username: z
    .string()
    .min(3, "Kullanıcı adı en az 3 karakter olmalı.")
    .max(20, "Kullanıcı adı en fazla 20 karakter olmalı.")
    .regex(/^[a-zA-Z0-9_]+$/, "Kullanıcı adı yalnızca harf, rakam ve alt çizgi içerebilir."),
  password: z.string().min(8, "Şifre en az 8 karakter olmalı."),
});

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get("x-forwarded-for") ?? "unknown";
    checkRateLimit(`register:${ip}`, 5, 60_000); // dakikada en fazla 5 kayıt denemesi / IP

    const body = await req.json();
    const parsed = registerSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message ?? "Geçersiz veri." },
        { status: 400 },
      );
    }

    const email = parsed.data.email.toLowerCase().trim();
    const username = parsed.data.username.trim();

    const existing = await prisma.user.findFirst({
      where: { OR: [{ email }, { username }] },
      select: { email: true, username: true },
    });
    if (existing) {
      const field = existing.email === email ? "E-posta" : "Kullanıcı adı";
      return NextResponse.json({ error: `${field} zaten kullanılıyor.` }, { status: 409 });
    }

    const passwordHash = await bcrypt.hash(parsed.data.password, 12);

    const user = await prisma.user.create({
      data: {
        email,
        username,
        passwordHash,
        role: "USER",
        points: 0,
        pointsPerClick: 0.2,
        clicksRemaining: 200,
        clickLimitMax: 200,
      },
      select: { id: true, email: true, username: true },
    });

    return NextResponse.json({ user }, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}
