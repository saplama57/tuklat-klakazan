import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiError, checkRateLimit, handleApiError, requireUser, utcDayStart } from "@/lib/security";

const LIMIT_RESET_MS = 5 * 60 * 1000; // 5 dakika

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();

    // Ek anti-bot koruması: aynı kullanıcı saniyede 8'den fazla istek atamaz.
    // (200 tıklamalık limit zaten asıl korumadır, bu ekstra bir katmandır.)
    checkRateLimit(`click:${user.id}`, 8, 1000);

    const now = new Date();

    const result = await prisma.$transaction(async (tx) => {
      // Satır kilidi için kullanıcıyı transaction içinde tekrar oku.
      const fresh = await tx.user.findUnique({ where: { id: user.id } });
      if (!fresh) throw new ApiError(401, "Kullanıcı bulunamadı.");
      if (fresh.isBanned) throw new ApiError(403, "Hesabınız askıya alınmış.");

      let clicksRemaining = fresh.clicksRemaining;
      let limitResetAt = fresh.limitResetAt;

      // Limit süresi dolmuşsa otomatik olarak yenile.
      if (clicksRemaining <= 0 && limitResetAt && limitResetAt.getTime() <= now.getTime()) {
        clicksRemaining = fresh.clickLimitMax;
        limitResetAt = null;
      }

      if (clicksRemaining <= 0) {
        const remainingMs = limitResetAt ? limitResetAt.getTime() - now.getTime() : LIMIT_RESET_MS;
        throw new ApiError(
          429,
          `Tıklama limitiniz doldu. ${Math.max(1, Math.ceil(remainingMs / 1000))} saniye sonra tekrar deneyin.`,
        );
      }

      // Aktif turbo(lar)dan en yüksek çarpanı bul.
      const activeTurbos = await tx.userTurbo.findMany({
        where: { userId: user.id, expiresAt: { gt: now } },
        include: { turboType: true },
      });
      const multiplier = activeTurbos.length
        ? Math.max(...activeTurbos.map((t) => Number(t.turboType.multiplier)))
        : 1;

      const pointsAwarded = Number(fresh.pointsPerClick) * multiplier;
      const newClicksRemaining = clicksRemaining - 1;
      const newLimitResetAt = newClicksRemaining <= 0 ? new Date(now.getTime() + LIMIT_RESET_MS) : limitResetAt;

      // Günlük seri (streak) hesabı
      const today = utcDayStart(now);
      let dailyStreak = fresh.dailyStreak;
      const lastActive = fresh.lastActiveDate ? utcDayStart(fresh.lastActiveDate) : null;
      if (!lastActive || lastActive.getTime() !== today.getTime()) {
        if (lastActive) {
          const diffDays = Math.round((today.getTime() - lastActive.getTime()) / 86_400_000);
          dailyStreak = diffDays === 1 ? dailyStreak + 1 : 1;
        } else {
          dailyStreak = 1;
        }
      }

      const updated = await tx.user.update({
        where: { id: user.id },
        data: {
          points: { increment: pointsAwarded },
          totalPointsEarned: { increment: pointsAwarded },
          totalClicks: { increment: 1 },
          clicksRemaining: newClicksRemaining,
          limitResetAt: newLimitResetAt,
          dailyStreak,
          lastActiveDate: now,
        },
      });

      await tx.clickEvent.create({
        data: { userId: user.id, pointsAwarded, multiplier },
      });

      // Günlük görev ilerlemesini güncelle (CLICK_COUNT ve POINTS_EARNED tipleri)
      const relevantTasks = await tx.dailyTask.findMany({
        where: { isActive: true, type: { in: ["CLICK_COUNT", "POINTS_EARNED"] } },
      });

      for (const task of relevantTasks) {
        const increment = task.type === "CLICK_COUNT" ? 1 : Math.round(pointsAwarded * 100) / 100;
        const existing = await tx.userTaskProgress.findUnique({
          where: { userId_taskId_progressDate: { userId: user.id, taskId: task.id, progressDate: today } },
        });
        const currentValue = (existing?.currentValue ?? 0) + increment;
        const isCompleted = currentValue >= task.targetValue;
        await tx.userTaskProgress.upsert({
          where: { userId_taskId_progressDate: { userId: user.id, taskId: task.id, progressDate: today } },
          create: {
            userId: user.id,
            taskId: task.id,
            progressDate: today,
            currentValue,
            isCompleted,
          },
          update: { currentValue, isCompleted },
        });
      }

      return { updated, pointsAwarded, multiplier };
    });

    return NextResponse.json({
      pointsAwarded: result.pointsAwarded,
      multiplier: result.multiplier,
      points: result.updated.points,
      clicksRemaining: result.updated.clicksRemaining,
      clickLimitMax: result.updated.clickLimitMax,
      limitResetAt: result.updated.limitResetAt,
      totalClicks: result.updated.totalClicks,
      dailyStreak: result.updated.dailyStreak,
    });
  } catch (err) {
    return handleApiError(err);
  }
}
