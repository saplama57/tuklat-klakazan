import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { handleApiError, requireUser } from "@/lib/security";

export async function GET() {
  try {
    const user = await requireUser();

    // userId: user.id filtresi kritik — kullanıcı başkasının envanterini
    // asla göremez (URL/parametre manipülasyonu ile de erişilemez, çünkü
    // ID bu endpoint'te dışarıdan alınmıyor, oturumdan geliyor).
    const items = await prisma.inventoryItem.findMany({
      where: { userId: user.id },
      include: {
        product: { select: { name: true, imageUrl: true, category: true } },
        order: { select: { orderNumber: true, createdAt: true, totalPrice: true } },
      },
      orderBy: { acquiredAt: "desc" },
    });

    return NextResponse.json({ items });
  } catch (err) {
    return handleApiError(err);
  }
}
