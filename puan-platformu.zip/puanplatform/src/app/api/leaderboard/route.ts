import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { handleApiError, requireUser } from "@/lib/security";

const CATEGORIES = ["points", "clicks", "streak", "rewards"] as const;
type Category = (typeof CATEGORIES)[number];

export async function GET(req: NextRequest) {
  try {
    await requireUser();
    const categoryParam = req.nextUrl.searchParams.get("category") ?? "points";
    const category = (CATEGORIES.includes(categoryParam as Category) ? categoryParam : "points") as Category;

    const orderBy =
      category === "points"
        ? { points: "desc" as const }
        : category === "clicks"
          ? { totalClicks: "desc" as const }
          : category === "streak"
            ? { dailyStreak: "desc" as const }
            : { totalRewardsClaimed: "desc" as const };

    const users = await prisma.user.findMany({
      where: { isBanned: false },
      orderBy,
      take: 50,
      select: {
        id: true,
        username: true,
        avatarUrl: true,
        points: true,
        totalClicks: true,
        dailyStreak: true,
        totalRewardsClaimed: true,
      },
    });

    return NextResponse.json({
      category,
      entries: users.map((u, idx) => ({ rank: idx + 1, ...u })),
    });
  } catch (err) {
    return handleApiError(err);
  }
}
