import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, handleApiError, requireAdmin, writeAdminLog } from "@/lib/security";

const updateSchema = z.object({
  name: z.string().min(2).max(120).optional(),
  description: z.string().max(2000).nullable().optional(),
  imageUrl: z.string().url().nullable().optional(),
  price: z.number().positive().optional(),
  stock: z.number().int().min(0).optional(),
  category: z.string().min(1).max(60).optional(),
  status: z.enum(["ACTIVE", "HIDDEN", "OUT_OF_STOCK"]).optional(),
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const admin = await requireAdmin("PRODUCT_MANAGEMENT");
    const body = await req.json();
    const parsed = updateSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Geçersiz veri." }, { status: 400 });
    }

    const existing = await prisma.product.findUnique({ where: { id: params.id } });
    if (!existing) throw new ApiError(404, "Ürün bulunamadı.");

    const updated = await prisma.product.update({
      where: { id: params.id },
      data: parsed.data,
    });

    await writeAdminLog({
      actorId: admin.id,
      action: "PRODUCT_UPDATE",
      oldValue: JSON.stringify(existing),
      newValue: JSON.stringify(updated),
    });

    return NextResponse.json({ product: updated });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const admin = await requireAdmin("PRODUCT_MANAGEMENT");
    const existing = await prisma.product.findUnique({ where: { id: params.id } });
    if (!existing) throw new ApiError(404, "Ürün bulunamadı.");

    // Sipariş geçmişi bütünlüğü için gerçek silme yerine gizleniyor.
    const updated = await prisma.product.update({
      where: { id: params.id },
      data: { status: "HIDDEN" },
    });

    await writeAdminLog({
      actorId: admin.id,
      action: "PRODUCT_HIDE",
      oldValue: JSON.stringify(existing),
      newValue: JSON.stringify(updated),
    });

    return NextResponse.json({ product: updated });
  } catch (err) {
    return handleApiError(err);
  }
}
