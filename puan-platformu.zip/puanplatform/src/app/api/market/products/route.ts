import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { handleApiError, notifyUser, requireAdmin, requireUser, writeAdminLog } from "@/lib/security";

export async function GET() {
  try {
    await requireUser();
    const products = await prisma.product.findMany({
      where: { status: { in: ["ACTIVE", "OUT_OF_STOCK"] } },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ products });
  } catch (err) {
    return handleApiError(err);
  }
}

const createSchema = z.object({
  name: z.string().min(2).max(120),
  description: z.string().max(2000).optional(),
  imageUrl: z.string().url().optional().or(z.literal("")),
  price: z.number().positive(),
  stock: z.number().int().min(0),
  category: z.string().min(1).max(60),
});

export async function POST(req: NextRequest) {
  try {
    const admin = await requireAdmin("PRODUCT_MANAGEMENT");
    const body = await req.json();
    const parsed = createSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message ?? "Geçersiz veri." },
        { status: 400 },
      );
    }

    const product = await prisma.product.create({
      data: {
        name: parsed.data.name,
        description: parsed.data.description || null,
        imageUrl: parsed.data.imageUrl || null,
        price: parsed.data.price,
        stock: parsed.data.stock,
        category: parsed.data.category,
        status: parsed.data.stock > 0 ? "ACTIVE" : "OUT_OF_STOCK",
      },
    });

    await writeAdminLog({
      actorId: admin.id,
      action: "PRODUCT_CREATE",
      newValue: JSON.stringify(product),
    });

    // Tüm kullanıcılara "yeni ürün" bildirimi yerine, veritabanı büyükse
    // toplu bildirim yerine sadece duyuru üretmek daha verimlidir; burada
    // örnek olması için ilk 500 aktif kullanıcıya bildirim gönderilir.
    const users = await prisma.user.findMany({
      where: { isBanned: false },
      select: { id: true },
      take: 500,
    });
    await prisma.notification.createMany({
      data: users.map((u) => ({
        userId: u.id,
        type: "NEW_PRODUCT" as const,
        title: "Yeni ürün eklendi",
        message: `${product.name} markette satışa çıktı.`,
      })),
    });

    return NextResponse.json({ product }, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}
