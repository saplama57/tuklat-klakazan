import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, checkRateLimit, handleApiError, notifyUser, requireUser, utcDayStart } from "@/lib/security";

const schema = z.object({
  productId: z.string().min(1),
  quantity: z.number().int().min(1).max(20).default(1),
});

function generateOrderNumber() {
  const stamp = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `ORD-${stamp}-${rand}`;
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    checkRateLimit(`purchase:${user.id}`, 10, 5000);

    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Geçersiz istek." }, { status: 400 });
    }
    const { productId, quantity } = parsed.data;

    const result = await prisma.$transaction(async (tx) => {
      // Ürünü kilitli şekilde oku (stok/fiyat yarış koşullarını önlemek için).
      const product = await tx.product.findUnique({ where: { id: productId } });
      if (!product || product.status === "HIDDEN") {
        throw new ApiError(404, "Ürün bulunamadı.");
      }
      if (product.stock < quantity) {
        throw new ApiError(400, "Yetersiz stok.");
      }

      const totalPrice = Number(product.price) * quantity;

      const fresh = await tx.user.findUniqueOrThrow({ where: { id: user.id } });
      if (Number(fresh.points) < totalPrice) {
        throw new ApiError(400, "Yeterli puanınız yok.");
      }

      // Stoğu koşullu olarak düş — eşzamanlı isteklerde negatif stok imkansız.
      const stockUpdate = await tx.product.updateMany({
        where: { id: productId, stock: { gte: quantity } },
        data: { stock: { decrement: quantity } },
      });
      if (stockUpdate.count === 0) {
        throw new ApiError(400, "Yetersiz stok.");
      }

      const remainingStock = product.stock - quantity;
      if (remainingStock <= 0) {
        await tx.product.update({ where: { id: productId }, data: { status: "OUT_OF_STOCK" } });
      }

      const updatedUser = await tx.user.update({
        where: { id: user.id },
        data: { points: { decrement: totalPrice } },
      });

      const order = await tx.order.create({
        data: {
          orderNumber: generateOrderNumber(),
          userId: user.id,
          productId: product.id,
          quantity,
          unitPrice: product.price,
          totalPrice,
          status: "COMPLETED",
        },
      });

      const inventoryItem = await tx.inventoryItem.create({
        data: { userId: user.id, productId: product.id, orderId: order.id, status: "ACTIVE" },
      });

      // MARKET_PURCHASE tipi günlük görevleri güncelle
      const today = utcDayStart();
      const marketTasks = await tx.dailyTask.findMany({
        where: { isActive: true, type: "MARKET_PURCHASE" },
      });
      for (const task of marketTasks) {
        const existing = await tx.userTaskProgress.findUnique({
          where: { userId_taskId_progressDate: { userId: user.id, taskId: task.id, progressDate: today } },
        });
        const currentValue = (existing?.currentValue ?? 0) + 1;
        await tx.userTaskProgress.upsert({
          where: { userId_taskId_progressDate: { userId: user.id, taskId: task.id, progressDate: today } },
          create: {
            userId: user.id,
            taskId: task.id,
            progressDate: today,
            currentValue,
            isCompleted: currentValue >= task.targetValue,
          },
          update: { currentValue, isCompleted: currentValue >= task.targetValue },
        });
      }

      return { updatedUser, order, inventoryItem, product };
    });

    await notifyUser({
      userId: user.id,
      type: "PURCHASE_CONFIRMED",
      title: "Satın alma başarılı",
      message: `${result.product.name} envanterinize eklendi. Sipariş no: ${result.order.orderNumber}`,
    });

    return NextResponse.json({
      points: result.updatedUser.points,
      order: result.order,
      inventoryItemId: result.inventoryItem.id,
    });
  } catch (err) {
    return handleApiError(err);
  }
}
