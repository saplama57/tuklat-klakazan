import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { ApiError, handleApiError, requireUser } from "@/lib/security";

export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = await requireUser();
    const notification = await prisma.notification.findUnique({ where: { id: params.id } });
    if (!notification || notification.userId !== user.id) {
      throw new ApiError(404, "Bildirim bulunamadı.");
    }
    await prisma.notification.update({ where: { id: params.id }, data: { isRead: true } });
    return NextResponse.json({ success: true });
  } catch (err) {
    return handleApiError(err);
  }
}
