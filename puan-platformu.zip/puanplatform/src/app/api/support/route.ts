import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { handleApiError, requireAdmin, requireUser } from "@/lib/security";

const schema = z.object({ subject: z.string().min(3).max(150), message: z.string().min(5).max(3000) });

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) return NextResponse.json({ error: "Geçersiz veri." }, { status: 400 });

    const ticket = await prisma.supportTicket.create({
      data: { userId: user.id, subject: parsed.data.subject, message: parsed.data.message },
    });
    return NextResponse.json({ ticket }, { status: 201 });
  } catch (err) {
    return handleApiError(err);
  }
}

export async function GET() {
  try {
    await requireAdmin("SUPPORT_MANAGEMENT");
    const tickets = await prisma.supportTicket.findMany({
      include: { user: { select: { username: true, email: true } } },
      orderBy: { createdAt: "desc" },
      take: 100,
    });
    return NextResponse.json({ tickets });
  } catch (err) {
    return handleApiError(err);
  }
}
