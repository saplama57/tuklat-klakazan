import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, checkRateLimit, handleApiError, notifyUser, requireUser, utcDayStart } from "@/lib/security";

const schema = z.object({ taskId: z.string().min(1) });

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    checkRateLimit(`task-claim:${user.id}`, 10, 5000);

    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Geçersiz istek." }, { status: 400 });
    }

    const today = utcDayStart();

    const result = await prisma.$transaction(async (tx) => {
      const task = await tx.dailyTask.findUnique({ where: { id: parsed.data.taskId } });
      if (!task || !task.isActive) throw new ApiError(404, "Görev bulunamadı.");

      const progress = await tx.userTaskProgress.findUnique({
        where: { userId_taskId_progressDate: { userId: user.id, taskId: task.id, progressDate: today } },
      });

      if (!progress || !progress.isCompleted) {
        throw new ApiError(400, "Görev henüz tamamlanmadı.");
      }
      if (progress.isClaimed) {
        throw new ApiError(409, "Bu görevin ödülü zaten alındı.");
      }

      await tx.userTaskProgress.update({
        where: { id: progress.id },
        data: { isClaimed: true, claimedAt: new Date() },
      });

      const updatedUser = await tx.user.update({
        where: { id: user.id },
        data: {
          points: { increment: task.rewardPoints },
          totalRewardsClaimed: { increment: 1 },
        },
      });

      return { updatedUser, task };
    });

    await notifyUser({
      userId: user.id,
      type: "REWARD_CLAIMED",
      title: "Ödül alındı",
      message: `'${result.task.title}' görevinden ${result.task.rewardPoints} puan kazandınız.`,
    });

    return NextResponse.json({ points: result.updatedUser.points });
  } catch (err) {
    return handleApiError(err);
  }
}
