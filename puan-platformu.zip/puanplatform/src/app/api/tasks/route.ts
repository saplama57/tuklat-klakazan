import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { handleApiError, requireUser, utcDayStart } from "@/lib/security";

export async function GET() {
  try {
    const user = await requireUser();
    const today = utcDayStart();

    const tasks = await prisma.dailyTask.findMany({ where: { isActive: true } });

    // Kullanıcı bugün bu endpoint'i çağırdığına göre aktif olarak giriş
    // yapmıştır — DAILY_LOGIN tipi görevleri otomatik tamamla.
    const loginTasks = tasks.filter((t) => t.type === "DAILY_LOGIN");
    for (const t of loginTasks) {
      await prisma.userTaskProgress.upsert({
        where: { userId_taskId_progressDate: { userId: user.id, taskId: t.id, progressDate: today } },
        create: { userId: user.id, taskId: t.id, progressDate: today, currentValue: 1, isCompleted: true },
        update: { currentValue: 1, isCompleted: true },
      });
    }

    const progress = await prisma.userTaskProgress.findMany({
      where: { userId: user.id, progressDate: today },
    });
    const progressByTask = new Map(progress.map((p) => [p.taskId, p]));

    return NextResponse.json({
      tasks: tasks.map((t) => {
        const p = progressByTask.get(t.id);
        return {
          id: t.id,
          key: t.key,
          title: t.title,
          description: t.description,
          type: t.type,
          targetValue: t.targetValue,
          rewardPoints: t.rewardPoints,
          currentValue: p?.currentValue ?? 0,
          isCompleted: p?.isCompleted ?? false,
          isClaimed: p?.isClaimed ?? false,
        };
      }),
    });
  } catch (err) {
    return handleApiError(err);
  }
}
