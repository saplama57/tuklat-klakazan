import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, checkRateLimit, handleApiError, notifyUser, requireUser } from "@/lib/security";

const schema = z.object({ turboTypeId: z.string().min(1) });

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    checkRateLimit(`turbo-purchase:${user.id}`, 10, 5000);

    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Geçersiz istek." }, { status: 400 });
    }

    const now = new Date();

    const result = await prisma.$transaction(async (tx) => {
      const turboType = await tx.turboType.findUnique({ where: { id: parsed.data.turboTypeId } });
      if (!turboType || !turboType.isActive) {
        throw new ApiError(404, "Turbo bulunamadı.");
      }

      const fresh = await tx.user.findUniqueOrThrow({ where: { id: user.id } });
      if (Number(fresh.points) < Number(turboType.price)) {
        throw new ApiError(400, "Yeterli puanınız yok.");
      }

      // Aktif bir turbo varsa, yeni turbo onun bitişinden itibaren başlar
      // (üst üste satın alınan turbolar art arda eklenir, üzerine yazılmaz).
      const activeTurbo = await tx.userTurbo.findFirst({
        where: { userId: user.id, expiresAt: { gt: now } },
        orderBy: { expiresAt: "desc" },
      });
      const startFrom = activeTurbo && activeTurbo.expiresAt > now ? activeTurbo.expiresAt : now;
      const expiresAt = new Date(startFrom.getTime() + turboType.durationSec * 1000);

      const updatedUser = await tx.user.update({
        where: { id: user.id },
        data: { points: { decrement: turboType.price } },
      });

      const userTurbo = await tx.userTurbo.create({
        data: { userId: user.id, turboTypeId: turboType.id, expiresAt },
      });

      return { updatedUser, userTurbo, turboType };
    });

    await notifyUser({
      userId: user.id,
      type: "ADMIN_ACTION",
      title: "Turbo aktif edildi",
      message: `${result.turboType.name} aktif — ${result.turboType.multiplier}x puan çarpanı.`,
    });

    return NextResponse.json({
      points: result.updatedUser.points,
      expiresAt: result.userTurbo.expiresAt,
      multiplier: result.turboType.multiplier,
    });
  } catch (err) {
    return handleApiError(err);
  }
}
