import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { handleApiError, requireUser } from "@/lib/security";

export async function GET() {
  try {
    await requireUser();
    const turbos = await prisma.turboType.findMany({
      where: { isActive: true },
      orderBy: { price: "asc" },
    });
    return NextResponse.json({ turbos });
  } catch (err) {
    return handleApiError(err);
  }
}
