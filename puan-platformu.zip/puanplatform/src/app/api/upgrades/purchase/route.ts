import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { ApiError, checkRateLimit, handleApiError, notifyUser, requireUser } from "@/lib/security";

const schema = z.object({ upgradeId: z.string().min(1) });

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    checkRateLimit(`upgrade-purchase:${user.id}`, 10, 5000);

    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Geçersiz istek." }, { status: 400 });
    }

    const result = await prisma.$transaction(async (tx) => {
      const upgrade = await tx.upgrade.findUnique({ where: { id: parsed.data.upgradeId } });
      if (!upgrade || !upgrade.isActive) {
        throw new ApiError(404, "Yükseltme bulunamadı.");
      }

      const alreadyOwned = await tx.userUpgrade.findUnique({
        where: { userId_upgradeId: { userId: user.id, upgradeId: upgrade.id } },
      });
      if (alreadyOwned) {
        throw new ApiError(409, "Bu yükseltmeye zaten sahipsiniz.");
      }

      // Aynı zincirin (key) bir önceki seviyesine sahip olmalı (seviye 1 hariç).
      if (upgrade.level > 1) {
        const previousLevel = await tx.upgrade.findFirst({
          where: { key: upgrade.key, level: upgrade.level - 1 },
        });
        if (previousLevel) {
          const ownsPrevious = await tx.userUpgrade.findUnique({
            where: { userId_upgradeId: { userId: user.id, upgradeId: previousLevel.id } },
          });
          if (!ownsPrevious) {
            throw new ApiError(400, `Önce '${previousLevel.name}' (Seviye ${previousLevel.level}) satın almalısınız.`);
          }
        }
      }

      const fresh = await tx.user.findUniqueOrThrow({ where: { id: user.id } });
      if (Number(fresh.points) < Number(upgrade.price)) {
        throw new ApiError(400, "Yeterli puanınız yok.");
      }

      const updatedUser = await tx.user.update({
        where: { id: user.id },
        data: {
          points: { decrement: upgrade.price },
          pointsPerClick: upgrade.pointsPerClick,
        },
      });

      await tx.userUpgrade.create({
        data: { userId: user.id, upgradeId: upgrade.id },
      });

      return { updatedUser, upgrade };
    });

    await notifyUser({
      userId: user.id,
      type: "ADMIN_ACTION",
      title: "Yükseltme satın alındı",
      message: `${result.upgrade.name} (Seviye ${result.upgrade.level}) aktif edildi.`,
    });

    return NextResponse.json({
      points: result.updatedUser.points,
      pointsPerClick: result.updatedUser.pointsPerClick,
    });
  } catch (err) {
    return handleApiError(err);
  }
}
