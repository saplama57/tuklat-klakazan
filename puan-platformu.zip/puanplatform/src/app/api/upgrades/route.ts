import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { handleApiError, requireUser } from "@/lib/security";

export async function GET() {
  try {
    const user = await requireUser();

    const upgrades = await prisma.upgrade.findMany({
      where: { isActive: true },
      orderBy: [{ key: "asc" }, { level: "asc" }],
    });

    const owned = await prisma.userUpgrade.findMany({
      where: { userId: user.id },
      select: { upgradeId: true },
    });
    const ownedIds = new Set(owned.map((o) => o.upgradeId));

    return NextResponse.json({
      upgrades: upgrades.map((u) => ({ ...u, owned: ownedIds.has(u.id) })),
    });
  } catch (err) {
    return handleApiError(err);
  }
}
