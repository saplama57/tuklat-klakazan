import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { handleApiError, requireUser } from "@/lib/security";

export async function GET() {
  try {
    const user = await requireUser();
    const now = new Date();

    // Limit süresi dolmuşsa burada da otomatik yenile (kullanıcı sayfayı
    // sadece yenilediğinde bile /api/click çağırmadan doğru değeri görsün).
    let clicksRemaining = user.clicksRemaining;
    let limitResetAt = user.limitResetAt;
    if (clicksRemaining <= 0 && limitResetAt && limitResetAt.getTime() <= now.getTime()) {
      const refreshed = await prisma.user.update({
        where: { id: user.id },
        data: { clicksRemaining: user.clickLimitMax, limitResetAt: null },
      });
      clicksRemaining = refreshed.clicksRemaining;
      limitResetAt = refreshed.limitResetAt;
    }

    const activeTurbos = await prisma.userTurbo.findMany({
      where: { userId: user.id, expiresAt: { gt: now } },
      include: { turboType: true },
      orderBy: { expiresAt: "desc" },
    });

    const upgrades = await prisma.userUpgrade.findMany({
      where: { userId: user.id },
      include: { upgrade: true },
    });

    return NextResponse.json({
      id: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
      avatarUrl: user.avatarUrl,
      points: user.points,
      pointsPerClick: user.pointsPerClick,
      clicksRemaining,
      clickLimitMax: user.clickLimitMax,
      limitResetAt,
      totalClicks: user.totalClicks,
      totalPointsEarned: user.totalPointsEarned,
      dailyStreak: user.dailyStreak,
      activeTurbos: activeTurbos.map((t) => ({
        id: t.id,
        name: t.turboType.name,
        icon: t.turboType.icon,
        multiplier: t.turboType.multiplier,
        expiresAt: t.expiresAt,
      })),
      ownedUpgradeKeys: upgrades.map((u) => u.upgrade.key),
    });
  } catch (err) {
    return handleApiError(err);
  }
}
