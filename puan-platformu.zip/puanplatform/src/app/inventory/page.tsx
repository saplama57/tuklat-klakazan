"use client";

import { useEffect, useState } from "react";

type Item = {
  id: string;
  status: string;
  acquiredAt: string;
  product: { name: string; imageUrl: string | null; category: string };
  order: { orderNumber: string; createdAt: string; totalPrice: string };
};

export default function InventoryPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/inventory")
      .then((r) => r.json())
      .then((d) => setItems(d.items ?? []))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">🎒 Envanterim</h1>
      {loading && <p className="text-white/50">Yükleniyor...</p>}

      <div className="card divide-y divide-white/10">
        {items.map((item) => (
          <div key={item.id} className="flex items-center justify-between px-5 py-3">
            <div className="flex items-center gap-3">
              {item.product.imageUrl && (
                <img src={item.product.imageUrl} alt="" className="h-10 w-10 rounded-lg object-cover" />
              )}
              <div>
                <p className="font-semibold">{item.product.name}</p>
                <p className="text-xs text-white/40">
                  Sipariş: {item.order.orderNumber} · {new Date(item.order.createdAt).toLocaleString("tr-TR")}
                </p>
              </div>
            </div>
            <span
              className={`rounded-lg px-2 py-1 text-xs font-semibold ${
                item.status === "ACTIVE"
                  ? "bg-emerald-500/20 text-emerald-300"
                  : item.status === "USED"
                    ? "bg-white/10 text-white/50"
                    : "bg-red-500/20 text-red-300"
              }`}
            >
              {item.status === "ACTIVE" ? "Aktif" : item.status === "USED" ? "Kullanıldı" : "Süresi doldu"}
            </span>
          </div>
        ))}
        {!loading && items.length === 0 && <p className="p-6 text-center text-white/50">Envanterinizde ürün yok.</p>}
      </div>
    </div>
  );
}
