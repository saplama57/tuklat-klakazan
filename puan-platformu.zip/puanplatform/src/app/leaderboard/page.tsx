"use client";

import { useEffect, useState } from "react";

type Entry = {
  rank: number;
  id: string;
  username: string;
  avatarUrl: string | null;
  points: string;
  totalClicks: number;
  dailyStreak: number;
  totalRewardsClaimed: number;
};

const CATEGORIES = [
  { key: "points", label: "🏆 En Çok Puan", valueKey: "points" as const, suffix: "P" },
  { key: "clicks", label: "👆 En Çok Tıklama", valueKey: "totalClicks" as const, suffix: "" },
  { key: "streak", label: "🔥 En Uzun Günlük Seri", valueKey: "dailyStreak" as const, suffix: " gün" },
  { key: "rewards", label: "🎁 En Çok Ödül", valueKey: "totalRewardsClaimed" as const, suffix: "" },
];

export default function LeaderboardPage() {
  const [category, setCategory] = useState("points");
  const [entries, setEntries] = useState<Entry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/leaderboard?category=${category}`)
      .then((r) => r.json())
      .then((d) => setEntries(d.entries ?? []))
      .finally(() => setLoading(false));
  }, [category]);

  const activeCat = CATEGORIES.find((c) => c.key === category)!;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Liderlik Tablosu</h1>

      <div className="flex flex-wrap gap-2">
        {CATEGORIES.map((c) => (
          <button
            key={c.key}
            onClick={() => setCategory(c.key)}
            className={`rounded-xl px-3 py-2 text-sm font-semibold transition ${
              category === c.key ? "bg-brand-600" : "bg-white/5 hover:bg-white/10"
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      <div className="card divide-y divide-white/10">
        {loading && <p className="p-6 text-center text-white/50">Yükleniyor...</p>}
        {!loading && entries.length === 0 && <p className="p-6 text-center text-white/50">Henüz veri yok.</p>}
        {entries.map((e) => (
          <div key={e.id} className="flex items-center justify-between px-5 py-3">
            <div className="flex items-center gap-3">
              <span
                className={`w-8 text-center font-bold ${
                  e.rank === 1 ? "text-amber-400" : e.rank === 2 ? "text-slate-300" : e.rank === 3 ? "text-orange-400" : "text-white/40"
                }`}
              >
                #{e.rank}
              </span>
              <span className="font-semibold">{e.username}</span>
            </div>
            <span className="font-bold tabular-nums">
              {activeCat.valueKey === "points" ? Number(e.points).toFixed(2) : e[activeCat.valueKey]}
              {activeCat.suffix}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
