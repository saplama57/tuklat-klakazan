"use client";

import { useEffect, useState } from "react";

type Product = {
  id: string;
  name: string;
  description: string | null;
  imageUrl: string | null;
  price: string;
  stock: number;
  category: string;
  status: string;
};

export default function MarketPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [buyingId, setBuyingId] = useState<string | null>(null);

  function load() {
    setLoading(true);
    fetch("/api/market/products")
      .then((r) => r.json())
      .then((d) => setProducts(d.products ?? []))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function buy(productId: string) {
    setError(null);
    setSuccess(null);
    setBuyingId(productId);
    try {
      const res = await fetch("/api/market/purchase", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, quantity: 1 }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error);
        return;
      }
      setSuccess(`Sipariş oluşturuldu: ${data.order.orderNumber}`);
      load();
    } finally {
      setBuyingId(null);
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">🛒 Market</h1>
      {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-400">{error}</p>}
      {success && <p className="rounded-lg bg-emerald-500/10 px-3 py-2 text-sm text-emerald-300">{success}</p>}
      {loading && <p className="text-white/50">Yükleniyor...</p>}

      <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
        {products.map((p) => (
          <div key={p.id} className="card flex flex-col overflow-hidden">
            {p.imageUrl && <img src={p.imageUrl} alt={p.name} className="h-32 w-full object-cover" />}
            <div className="flex flex-1 flex-col gap-2 p-4">
              <p className="text-xs uppercase tracking-wide text-white/40">{p.category}</p>
              <p className="font-semibold">{p.name}</p>
              {p.description && <p className="line-clamp-2 flex-1 text-sm text-white/50">{p.description}</p>}
              <div className="flex items-center justify-between pt-2">
                <span className="font-bold">{Number(p.price).toFixed(2)} P</span>
                <span className="text-xs text-white/40">Stok: {p.stock}</span>
              </div>
              <button
                disabled={p.stock <= 0 || buyingId === p.id}
                onClick={() => buy(p.id)}
                className="btn-primary mt-1 w-full"
              >
                {p.stock <= 0 ? "Stokta yok" : buyingId === p.id ? "İşleniyor..." : "Satın Al"}
              </button>
            </div>
          </div>
        ))}
        {!loading && products.length === 0 && <p className="text-white/50">Şu anda ürün yok.</p>}
      </div>
    </div>
  );
}
