"use client";

import { useCallback, useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

type Me = {
  points: string;
  pointsPerClick: string;
  clicksRemaining: number;
  clickLimitMax: number;
  limitResetAt: string | null;
  totalClicks: number;
  dailyStreak: number;
  activeTurbos: { id: string; name: string; icon: string; multiplier: string; expiresAt: string }[];
  ownedUpgradeKeys: string[];
};

type Upgrade = {
  id: string;
  key: string;
  name: string;
  description: string | null;
  icon: string;
  level: number;
  pointsPerClick: string;
  price: string;
  owned: boolean;
};

type Turbo = { id: string; name: string; icon: string; multiplier: string; durationSec: number; price: string };

function formatCountdown(ms: number) {
  if (ms <= 0) return "0:00";
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export default function HomePage() {
  const { status } = useSession();
  const router = useRouter();
  const [me, setMe] = useState<Me | null>(null);
  const [upgrades, setUpgrades] = useState<Upgrade[]>([]);
  const [turbos, setTurbos] = useState<Turbo[]>([]);
  const [now, setNow] = useState(Date.now());
  const [clicking, setClicking] = useState(false);
  const [flash, setFlash] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (status === "unauthenticated") router.push("/login");
  }, [status, router]);

  const loadMe = useCallback(async () => {
    const res = await fetch("/api/user/me");
    if (res.ok) setMe(await res.json());
  }, []);

  const loadUpgrades = useCallback(async () => {
    const res = await fetch("/api/upgrades");
    if (res.ok) setUpgrades((await res.json()).upgrades);
  }, []);

  const loadTurbos = useCallback(async () => {
    const res = await fetch("/api/turbo");
    if (res.ok) setTurbos((await res.json()).turbos);
  }, []);

  useEffect(() => {
    if (status !== "authenticated") return;
    loadMe();
    loadUpgrades();
    loadTurbos();
    const interval = setInterval(() => setNow(Date.now()), 1000);
    // Limit süresi dolduğunda backend'den taze veriyi çek.
    const pollInterval = setInterval(loadMe, 15000);
    return () => {
      clearInterval(interval);
      clearInterval(pollInterval);
    };
  }, [status, loadMe, loadUpgrades, loadTurbos]);

  async function handleClick() {
    if (clicking || !me || me.clicksRemaining <= 0) return;
    setClicking(true);
    setError(null);
    try {
      const res = await fetch("/api/click", { method: "POST" });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Bir hata oluştu.");
        await loadMe();
        return;
      }
      setMe((prev) =>
        prev
          ? {
              ...prev,
              points: data.points,
              clicksRemaining: data.clicksRemaining,
              limitResetAt: data.limitResetAt,
              totalClicks: data.totalClicks,
              dailyStreak: data.dailyStreak,
            }
          : prev,
      );
      setFlash(`+${Number(data.pointsAwarded).toFixed(2)}`);
      setTimeout(() => setFlash(null), 500);
    } finally {
      setClicking(false);
    }
  }

  async function buyUpgrade(id: string) {
    setError(null);
    const res = await fetch("/api/upgrades/purchase", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ upgradeId: id }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error);
      return;
    }
    await Promise.all([loadMe(), loadUpgrades()]);
  }

  async function buyTurbo(id: string) {
    setError(null);
    const res = await fetch("/api/turbo/purchase", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ turboTypeId: id }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error);
      return;
    }
    await loadMe();
  }

  if (status !== "authenticated" || !me) {
    return <div className="py-20 text-center text-white/50">Yükleniyor...</div>;
  }

  const limitExhausted = me.clicksRemaining <= 0;
  const resetMs = me.limitResetAt ? new Date(me.limitResetAt).getTime() - now : 0;

  return (
    <div className="grid gap-6 md:grid-cols-3">
      <div className="card flex flex-col items-center gap-6 p-8 md:col-span-2">
        <div className="text-center">
          <p className="text-sm uppercase tracking-widest text-white/50">Puanınız</p>
          <p className="text-5xl font-black tabular-nums">{Number(me.points).toFixed(2)}</p>
          {me.activeTurbos.length > 0 && (
            <p className="mt-2 text-sm text-amber-400">
              {me.activeTurbos.map((t) => `${t.icon} ${t.multiplier}x`).join(" · ")} aktif
            </p>
          )}
        </div>

        <div className="relative">
          <button
            onClick={handleClick}
            disabled={clicking || limitExhausted}
            className="relative h-48 w-48 rounded-full bg-gradient-to-br from-brand-500 to-brand-700 text-2xl font-black shadow-2xl shadow-brand-600/40 transition active:scale-95 disabled:cursor-not-allowed disabled:opacity-40 md:h-56 md:w-56"
          >
            PUAN KAZAN
            <div className="mt-1 text-sm font-normal text-white/80">+{Number(me.pointsPerClick).toFixed(2)} / tık</div>
          </button>
          {flash && (
            <div className="pointer-events-none absolute -top-6 left-1/2 -translate-x-1/2 text-xl font-bold text-emerald-400">
              {flash}
            </div>
          )}
        </div>

        <div className="w-full max-w-xs text-center">
          {limitExhausted ? (
            <div className="rounded-xl bg-red-500/10 px-4 py-3 text-red-300">
              Limit doldu — yenilenmesine <span className="font-bold">{formatCountdown(resetMs)}</span>
            </div>
          ) : (
            <div className="space-y-1">
              <p className="text-sm text-white/60">
                Kalan tıklama: <span className="font-semibold text-white">{me.clicksRemaining}</span> / {me.clickLimitMax}
              </p>
              <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full bg-brand-500 transition-all"
                  style={{ width: `${(me.clicksRemaining / me.clickLimitMax) * 100}%` }}
                />
              </div>
            </div>
          )}
        </div>

        <div className="flex gap-6 text-center text-sm text-white/60">
          <div>
            <p className="text-lg font-bold text-white">{me.totalClicks}</p>
            Toplam tıklama
          </div>
          <div>
            <p className="text-lg font-bold text-white">🔥 {me.dailyStreak}</p>
            Günlük seri
          </div>
        </div>

        {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-400">{error}</p>}
      </div>

      <div className="space-y-6">
        <div className="card p-5">
          <h2 className="mb-3 font-bold">🚀 Yükseltmeler</h2>
          <div className="space-y-2">
            {upgrades.map((u) => (
              <div key={u.id} className="flex items-center justify-between rounded-xl bg-white/5 px-3 py-2 text-sm">
                <div>
                  <p className="font-semibold">
                    {u.icon} {u.name} · Sv.{u.level}
                  </p>
                  <p className="text-white/50">+{Number(u.pointsPerClick).toFixed(2)} / tık</p>
                </div>
                {u.owned ? (
                  <span className="rounded-lg bg-emerald-500/20 px-2 py-1 text-xs text-emerald-300">Sahipsiniz</span>
                ) : (
                  <button onClick={() => buyUpgrade(u.id)} className="btn-primary py-1 text-xs">
                    {Number(u.price).toFixed(0)} P
                  </button>
                )}
              </div>
            ))}
            {upgrades.length === 0 && <p className="text-sm text-white/40">Henüz yükseltme yok.</p>}
          </div>
        </div>

        <div className="card p-5">
          <h2 className="mb-3 font-bold">⚡ Turbo</h2>
          <div className="space-y-2">
            {turbos.map((t) => (
              <div key={t.id} className="flex items-center justify-between rounded-xl bg-white/5 px-3 py-2 text-sm">
                <div>
                  <p className="font-semibold">
                    {t.icon} {t.name}
                  </p>
                  <p className="text-white/50">
                    {t.multiplier}x · {Math.round(t.durationSec / 60)} dk
                  </p>
                </div>
                <button onClick={() => buyTurbo(t.id)} className="btn-primary py-1 text-xs">
                  {Number(t.price).toFixed(0)} P
                </button>
              </div>
            ))}
            {turbos.length === 0 && <p className="text-sm text-white/40">Henüz turbo yok.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}
