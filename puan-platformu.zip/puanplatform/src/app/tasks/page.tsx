"use client";

import { useEffect, useState } from "react";

type Task = {
  id: string;
  title: string;
  description: string | null;
  targetValue: number;
  rewardPoints: string;
  currentValue: number;
  isCompleted: boolean;
  isClaimed: boolean;
};

export default function TasksPage() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  function load() {
    setLoading(true);
    fetch("/api/tasks")
      .then((r) => r.json())
      .then((d) => setTasks(d.tasks ?? []))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  async function claim(taskId: string) {
    setError(null);
    const res = await fetch("/api/tasks/claim", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ taskId }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error);
      return;
    }
    load();
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">📋 Günlük Görevler</h1>
      {error && <p className="rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-400">{error}</p>}
      {loading && <p className="text-white/50">Yükleniyor...</p>}

      <div className="grid gap-4 sm:grid-cols-2">
        {tasks.map((t) => {
          const pct = Math.min(100, (t.currentValue / t.targetValue) * 100);
          return (
            <div key={t.id} className="card p-5">
              <div className="mb-2 flex items-start justify-between">
                <div>
                  <p className="font-semibold">{t.title}</p>
                  {t.description && <p className="text-sm text-white/50">{t.description}</p>}
                </div>
                <span className="rounded-lg bg-brand-600/30 px-2 py-1 text-xs font-semibold text-brand-300">
                  +{Number(t.rewardPoints).toFixed(1)} P
                </span>
              </div>
              <div className="mb-3 h-2 w-full overflow-hidden rounded-full bg-white/10">
                <div className="h-full bg-emerald-500 transition-all" style={{ width: `${pct}%` }} />
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-white/60">
                  {Math.min(t.currentValue, t.targetValue)} / {t.targetValue}
                </span>
                {t.isClaimed ? (
                  <span className="rounded-lg bg-emerald-500/20 px-3 py-1 text-xs text-emerald-300">Alındı ✓</span>
                ) : (
                  <button
                    disabled={!t.isCompleted}
                    onClick={() => claim(t.id)}
                    className="btn-primary py-1 text-xs"
                  >
                    Ödülü Al
                  </button>
                )}
              </div>
            </div>
          );
        })}
        {!loading && tasks.length === 0 && <p className="text-white/50">Şu anda aktif görev yok.</p>}
      </div>
    </div>
  );
}
