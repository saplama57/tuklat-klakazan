"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut, useSession } from "next-auth/react";

const links = [
  { href: "/", label: "🎮 Ana Sayfa" },
  { href: "/tasks", label: "📋 Görevler" },
  { href: "/market", label: "🛒 Market" },
  { href: "/inventory", label: "🎒 Envanter" },
  { href: "/leaderboard", label: "🏆 Liderlik" },
];

export function Navbar() {
  const { data: session, status } = useSession();
  const pathname = usePathname();

  if (pathname === "/login" || pathname === "/register") return null;

  return (
    <header className="border-b border-white/10 bg-black/30 backdrop-blur">
      <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 px-4 py-3">
        <Link href="/" className="text-lg font-bold text-brand-500">
          ⚡ Puan Platformu
        </Link>
        {status === "authenticated" && (
          <nav className="flex flex-wrap items-center gap-2 text-sm">
            {links.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className={`rounded-lg px-3 py-1.5 transition hover:bg-white/10 ${
                  pathname === l.href ? "bg-white/10" : ""
                }`}
              >
                {l.label}
              </Link>
            ))}
            {(session.user.role === "ADMIN" || session.user.role === "SUPER_ADMIN") && (
              <Link
                href="/admin"
                className={`rounded-lg px-3 py-1.5 font-semibold text-amber-400 transition hover:bg-white/10 ${
                  pathname?.startsWith("/admin") ? "bg-white/10" : ""
                }`}
              >
                🛠️ Admin
              </Link>
            )}
            <span className="ml-2 text-white/60">{session.user.name}</span>
            <button onClick={() => signOut({ callbackUrl: "/login" })} className="btn-secondary py-1 text-xs">
              Çıkış
            </button>
          </nav>
        )}
      </div>
    </header>
  );
}
