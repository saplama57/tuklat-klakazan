import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import type { Role } from "@prisma/client";

/**
 * TÜM kritik state mutasyonları bu dosyadaki yardımcılardan geçer.
 * Amaç: hiçbir işlemin sadece client tarafından "güvenilerek" yapılmaması —
 * her istek burada kimlik doğrulama, rol kontrolü ve rate limiting'den geçer.
 */

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export async function requireSession() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) {
    throw new ApiError(401, "Oturum bulunamadı. Lütfen giriş yapın.");
  }
  return session;
}

export async function requireUser() {
  const session = await requireSession();
  const user = await prisma.user.findUnique({ where: { id: session.user.id } });
  if (!user) {
    throw new ApiError(401, "Kullanıcı bulunamadı.");
  }
  if (user.isBanned) {
    throw new ApiError(403, "Hesabınız yönetici tarafından askıya alınmış.");
  }
  return user;
}

/** ADMIN veya SUPER_ADMIN gerektirir. `permission` verilirse ADMIN için ayrıca
 *  AdminGrant.permissions içinde bu iznin bulunması zorunludur. SUPER_ADMIN her
 *  zaman geçer. */
export async function requireAdmin(permission?: string) {
  const session = await requireSession();
  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    include: { adminGrant: true },
  });
  if (!user) throw new ApiError(401, "Kullanıcı bulunamadı.");
  if (user.isBanned) throw new ApiError(403, "Hesap askıya alınmış.");

  if (user.role === "SUPER_ADMIN") return user;

  if (user.role !== "ADMIN") {
    throw new ApiError(403, "Bu işlem için yönetici yetkisi gereklidir.");
  }

  if (permission) {
    const perms = user.adminGrant?.permissions ?? [];
    if (!perms.includes(permission)) {
      throw new ApiError(403, `Bu işlem için '${permission}' yetkisine sahip değilsiniz.`);
    }
  }

  return user;
}

export function requireSuperAdminRole(role: Role) {
  if (role !== "SUPER_ADMIN") {
    throw new ApiError(403, "Bu işlem sadece SUPER_ADMIN tarafından yapılabilir.");
  }
}

export function handleApiError(err: unknown) {
  if (err instanceof ApiError) {
    return NextResponse.json({ error: err.message }, { status: err.status });
  }
  console.error("Unhandled API error:", err);
  return NextResponse.json({ error: "Sunucu hatası." }, { status: 500 });
}

/**
 * Basit sabit-pencere rate limiter — veritabanı destekli, tek instance'ta
 * bellekte tutulur. Tıklama endpoint'i zaten kendi limit sistemine sahip
 * olduğundan (200 tık / 5 dk reset), bu genel amaçlı ek bir koruma katmanıdır:
 * saniyede çok fazla istek atan bot/script'leri engeller.
 */
const rateBuckets = new Map<string, { count: number; resetAt: number }>();

export function checkRateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const bucket = rateBuckets.get(key);
  if (!bucket || bucket.resetAt < now) {
    rateBuckets.set(key, { count: 1, resetAt: now + windowMs });
    return;
  }
  bucket.count += 1;
  if (bucket.count > limit) {
    throw new ApiError(429, "Çok fazla istek gönderildi. Lütfen biraz bekleyin.");
  }
}

export async function writeAdminLog(params: {
  actorId: string;
  targetId?: string | null;
  action: string;
  oldValue?: string | null;
  newValue?: string | null;
  metadata?: Record<string, unknown>;
}) {
  await prisma.adminLog.create({
    data: {
      actorId: params.actorId,
      targetId: params.targetId ?? null,
      action: params.action,
      oldValue: params.oldValue ?? null,
      newValue: params.newValue ?? null,
      metadata: params.metadata ? (params.metadata as any) : undefined,
    },
  });
}

export async function notifyUser(params: {
  userId: string;
  type:
    | "LIMIT_RESET"
    | "NEW_PRODUCT"
    | "PURCHASE_CONFIRMED"
    | "REWARD_CLAIMED"
    | "ANNOUNCEMENT"
    | "ADMIN_ACTION";
  title: string;
  message: string;
}) {
  await prisma.notification.create({
    data: {
      userId: params.userId,
      type: params.type,
      title: params.title,
      message: params.message,
    },
  });
}

/** Bugünün UTC gün-başlangıcı — günlük görev/seri takibi bunu kullanır. */
export function utcDayStart(date: Date = new Date()) {
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
}
