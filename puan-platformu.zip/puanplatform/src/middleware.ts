import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

// NOT: Bu middleware yalnızca UX/defense-in-depth amaçlıdır. Gerçek yetki
// kontrolü her zaman ilgili API route'unda (requireAdmin / requireUser)
// yapılır — middleware bypass edilse bile backend güvenli kalır.
export default withAuth(
  function middleware(req) {
    const token = req.nextauth.token;
    const isAdminPath = req.nextUrl.pathname.startsWith("/admin");

    if (isAdminPath && token?.role !== "ADMIN" && token?.role !== "SUPER_ADMIN") {
      return NextResponse.redirect(new URL("/", req.url));
    }
    return NextResponse.next();
  },
  {
    pages: { signIn: "/login" },
    callbacks: {
      authorized: ({ token }) => !!token,
    },
  },
);

export const config = {
  matcher: ["/", "/leaderboard", "/market", "/inventory", "/tasks", "/admin/:path*"],
};
